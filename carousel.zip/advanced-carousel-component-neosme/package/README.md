# neutrinos-adv-carousel
Advanced Carousel Component for Neutrinos Platform.