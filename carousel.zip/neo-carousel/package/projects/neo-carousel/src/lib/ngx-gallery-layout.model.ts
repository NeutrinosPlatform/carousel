export class NgxGalleryLayout {
    static ThumbnailsTop = 'thumbnails-top';
    static ThumbnailsBottom = 'thumbnails-bottom';
}
