export class NgxGalleryImageSize {
    static Cover = 'cover';
    static Contain = 'contain';
}
