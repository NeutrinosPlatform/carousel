// import {} from 'jasmine';
// import { TestBed, inject, async } from '@angular/core/testing';
// import { NgxGalleryModule } from './';

// describe('NgxGallery', () => {
//     beforeEach(() => {
//         TestBed.configureTestingModule({
//             imports: [
//                 NgxGalleryModule
//             ]
//         })
//     })

//     it('should expect', () => {
//         expect(true).toBeTruthy()
//     })
// })
