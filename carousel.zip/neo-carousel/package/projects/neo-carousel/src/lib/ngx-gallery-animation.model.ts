export class NgxGalleryAnimation {
    static Fade = 'fade';
    static Slide = 'slide';
    static Rotate = 'rotate';
    static Zoom = 'zoom';
}
