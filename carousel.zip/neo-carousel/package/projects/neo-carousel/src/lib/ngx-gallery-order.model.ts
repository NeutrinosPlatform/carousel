export class NgxGalleryOrder {
    static Column = 1;
    static Row = 2;
    static Page = 3;
}
