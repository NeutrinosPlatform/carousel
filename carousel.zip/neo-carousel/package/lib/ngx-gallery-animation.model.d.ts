export declare class NgxGalleryAnimation {
    static Fade: string;
    static Slide: string;
    static Rotate: string;
    static Zoom: string;
}
