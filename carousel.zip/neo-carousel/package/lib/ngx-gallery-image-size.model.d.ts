export declare class NgxGalleryImageSize {
    static Cover: string;
    static Contain: string;
}
