export declare class NgxGalleryOrder {
    static Column: number;
    static Row: number;
    static Page: number;
}
