export declare class NgxGalleryLayout {
    static ThumbnailsTop: string;
    static ThumbnailsBottom: string;
}
